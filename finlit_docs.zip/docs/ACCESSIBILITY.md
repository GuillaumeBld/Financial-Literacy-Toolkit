# Accessibility

- WCAG 2.1 AA.
- Visible focus, keyboard complete.
- ARIA labels for stems, options, timers.
- High contrast toggle.
