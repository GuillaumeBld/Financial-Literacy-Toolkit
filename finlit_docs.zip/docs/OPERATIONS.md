# Operations

- Backups daily. Retention 30 to 90 days.
- Logs and alerts on 5xx, queue backlog, DB errors.
- Uptime checks.
- Release checklist in RELEASE_PLAYBOOK.md.
