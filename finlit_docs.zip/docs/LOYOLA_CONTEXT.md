# Loyola context

- Loyola University Chicago context for this project.
- Quinlan School of Business, Finance Department.
- Audience: enrolled finance students.
- Goal: measure level before and after the class only.
- Branding ties to Loyola and Quinlan. See BRAND_TOKENS.md.
