# Local development

- `pnpm --filter web dev` to run web.
- `pnpm --filter worker start` to run worker.
- Use a seeded test course and items.
- Unit tests and lint must pass before PR.
