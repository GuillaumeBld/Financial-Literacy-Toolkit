# Scoring and analytics

- Score MCQ and numeric by key.
- Compute domain and overall percent correct.
- Optional IRT after pilot using anchors to link.
- Change metrics: delta and within subject d.
- Overconfidence index: z(confidence) minus z(score) per domain.
- SHAP for feature importance after model training.
