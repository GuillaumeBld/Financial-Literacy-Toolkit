# API reference

- POST /api/attempts start
- GET /api/items next
- POST /api/responses
- POST /api/submit
- GET /api/scores

Auth: JWT with course scope. Rate limiting on start and submit.
