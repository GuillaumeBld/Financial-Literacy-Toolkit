# Adaptive testing

v2 only
- Start with 3 anchors per domain.
- Select next item by information with content balance.
- Stop at 15 to 20 items or SE threshold.
- Exposure control.
