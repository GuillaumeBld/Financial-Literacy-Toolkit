# FERPA compliance

- Do not store raw student IDs.
- Use salted hash per course.
- Limit access by role and course.
- Provide deletion on request.
- Document retention windows.
