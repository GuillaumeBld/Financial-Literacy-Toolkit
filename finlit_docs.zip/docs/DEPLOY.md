# Deploy

- Vercel for web. Set envs and link Postgres.
- Supabase or RDS for Postgres. Enable backups.
- Modal or Lambda for worker. Set DB URL and token.
- DNS for custom domain. TLS enabled.
- Uptime checks and alerts.
