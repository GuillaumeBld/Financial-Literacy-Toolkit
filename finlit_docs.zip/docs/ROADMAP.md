# Roadmap

- Pilot v1 fixed form.
- Add IRT calibration.
- Short form validation.
- Optional adaptive routing.
- LTI 1.3 self serve.
