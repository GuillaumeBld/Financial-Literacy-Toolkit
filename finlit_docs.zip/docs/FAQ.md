# FAQ

**Why only pre and post**
This project measures change across a course.

**How do you match students**
SSO or salted hash of Student ID. No raw IDs stored.
