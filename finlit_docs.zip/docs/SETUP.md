# Setup

1. Install Node 20 and Python 3.11.
2. Start Postgres via Docker.
3. Run migrations and seeds from infra.
4. Set env files as in ENVIRONMENT_VARIABLES.md.
5. Run web and worker locally.
