# Contributing

- Fork, branch, PR with description.
- Run lint and tests.
- Follow code style.
