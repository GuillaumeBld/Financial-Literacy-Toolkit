# License

Copyright 2025.
All rights reserved unless a license is added.
