# UX spec

- Start page with SSO or ID plus access code and consent.
- Assessment screen with timer, progress, confidence picker.
- Submission confirmation and success page.
- Student report pre and post. Instructor dashboard.
- Mobile ready, WCAG 2.1 AA.
