# SSO and LMS integration

- Preferred: LTI 1.3 SSO. Store opaque LMS user_id.
- Alternative: campus SSO via Okta or Azure AD.
- Fallback: access code plus hashed Student ID.
