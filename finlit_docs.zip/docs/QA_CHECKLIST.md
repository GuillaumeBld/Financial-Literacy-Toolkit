# QA checklist

- Forms render and submit on desktop and mobile.
- Timer and autosave work.
- RLS prevents cross course access.
- Reports match seeded data.
- Accessibility checks pass.
