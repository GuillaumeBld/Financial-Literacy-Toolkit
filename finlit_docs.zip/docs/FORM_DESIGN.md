# Form design

- Two forms: A pre, B post.
- Twelve anchors appear in both waves.
- 36 scored items per wave.
- Time limit 20 minutes.
- Item types: MCQ, numeric, short text, Likert confidence.
