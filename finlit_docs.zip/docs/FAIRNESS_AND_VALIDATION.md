# Fairness and validation

- Reliability target omega 0.80 or higher per domain.
- CFA for structure when available.
- DIF checks via logistic regression and IRT LR.
- Monitor residuals by subgroup for LLM scored items.
