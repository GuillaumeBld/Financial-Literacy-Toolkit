# Item bank

CSV columns
```
item_id,domain,subdomain,difficulty,type,stem,options_json,key_json,rubric_json,is_anchor
```
Include 72 items total, 12 anchors.
