# Security and privacy

- Pseudonymous keys only.
- Row Level Security by course.
- Rotate peppers each term.
- Rate limit sensitive endpoints.
- Optional purge of raw free text after scoring.
